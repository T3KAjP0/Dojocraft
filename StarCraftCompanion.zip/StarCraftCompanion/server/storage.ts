import {
  users,
  tournaments,
  replays,
  type User,
  type UpsertUser,
  type Tournament,
  type InsertTournament,
  type Replay,
  type InsertReplay,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT - mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Tournament operations
  getUserTournaments(userId: string): Promise<Tournament[]>;
  createTournament(tournament: InsertTournament): Promise<Tournament>;
  
  // Replay operations
  getUserReplays(userId: string): Promise<Replay[]>;
  createReplay(replay: InsertReplay): Promise<Replay>;
  updateReplayStatus(id: number, status: string, matchData?: any): Promise<void>;
  
  // Dashboard operations
  getDashboardStats(userId: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT - mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Tournament operations
  async getUserTournaments(userId: string): Promise<Tournament[]> {
    return await db.select().from(tournaments).where(eq(tournaments.userId, userId));
  }

  async createTournament(tournament: InsertTournament): Promise<Tournament> {
    const [newTournament] = await db
      .insert(tournaments)
      .values(tournament)
      .returning();
    return newTournament;
  }

  // Replay operations
  async getUserReplays(userId: string): Promise<Replay[]> {
    return await db
      .select()
      .from(replays)
      .where(eq(replays.userId, userId))
      .orderBy(desc(replays.createdAt));
  }

  async createReplay(replay: InsertReplay): Promise<Replay> {
    const [newReplay] = await db
      .insert(replays)
      .values(replay)
      .returning();
    return newReplay;
  }

  async updateReplayStatus(id: number, status: string, matchData?: any): Promise<void> {
    await db
      .update(replays)
      .set({
        status,
        matchData,
        updatedAt: new Date(),
      })
      .where(eq(replays.id, id));
  }

  // Dashboard operations
  async getDashboardStats(userId: string): Promise<any> {
    const userReplays = await this.getUserReplays(userId);
    const userTournaments = await this.getUserTournaments(userId);
    
    return {
      totalReplays: userReplays.length,
      tournaments: userTournaments.length,
      pendingReplays: userReplays.filter(r => r.status === 'processing').length,
      recentReplays: userReplays.slice(0, 5),
    };
  }
}

export const storage = new DatabaseStorage();