import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import multer from "multer";
import { insertTournamentSchema, insertReplaySchema } from "@shared/schema";

const upload = multer({ 
  dest: "uploads/",
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.originalname.endsWith('.rep')) {
      cb(null, true);
    } else {
      cb(new Error('Only .rep files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Tournament routes
  app.get('/api/tournaments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tournaments = await storage.getUserTournaments(userId);
      res.json(tournaments);
    } catch (error) {
      console.error("Error fetching tournaments:", error);
      res.status(500).json({ message: "Failed to fetch tournaments" });
    }
  });

  app.post('/api/tournaments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tournamentData = insertTournamentSchema.parse({
        ...req.body,
        userId
      });
      const tournament = await storage.createTournament(tournamentData);
      res.json(tournament);
    } catch (error) {
      console.error("Error creating tournament:", error);
      res.status(500).json({ message: "Failed to create tournament" });
    }
  });

  // Replay routes
  app.get('/api/replays', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const replays = await storage.getUserReplays(userId);
      res.json(replays);
    } catch (error) {
      console.error("Error fetching replays:", error);
      res.status(500).json({ message: "Failed to fetch replays" });
    }
  });

  app.post('/api/replays/upload', isAuthenticated, upload.single('replay'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const userId = req.user.claims.sub;
      const { tournamentId } = req.body;

      const replayData = insertReplaySchema.parse({
        filename: req.file.originalname,
        tournamentId: tournamentId ? parseInt(tournamentId) : null,
        userId,
        status: 'processing'
      });

      const replay = await storage.createReplay(replayData);
      
      // TODO: Implement actual replay processing
      // For now, simulate processing
      setTimeout(async () => {
        await storage.updateReplayStatus(replay.id, 'completed', {
          player1: 'Flash',
          player2: 'Jaedong',
          winner: 'Flash'
        });
      }, 2000);

      res.json(replay);
    } catch (error) {
      console.error("Error uploading replay:", error);
      res.status(500).json({ message: "Failed to upload replay" });
    }
  });

  // Dashboard stats route
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getDashboardStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
