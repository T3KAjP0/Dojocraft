export function StatusIndicator() {
  return (
    <div className="status-indicator flex items-center">
      <div className="w-2 h-2 rounded-full bg-[var(--starcraft-green)] mr-2"></div>
      <span className="text-xs font-orbitron">EN LÍNEA</span>
    </div>
  );
}
