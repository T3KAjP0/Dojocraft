import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface DataTerminalProps {
  children: ReactNode;
  className?: string;
}

export function DataTerminal({ children, className }: DataTerminalProps) {
  return (
    <div className={cn("data-terminal p-6", className)}>
      {children}
    </div>
  );
}
