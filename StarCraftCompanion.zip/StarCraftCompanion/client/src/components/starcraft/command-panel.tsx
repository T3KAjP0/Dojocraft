import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface CommandPanelProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}

export function CommandPanel({ children, className, onClick }: CommandPanelProps) {
  return (
    <div 
      className={cn(
        "command-panel p-6 transition-colors", 
        onClick && "cursor-pointer hover:bg-[var(--starcraft-gunmetal)]",
        className
      )}
      onClick={onClick}
    >
      {children}
    </div>
  );
}
