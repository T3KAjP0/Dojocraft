import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { StatusIndicator } from "@/components/starcraft/status-indicator";
import { Satellite } from "lucide-react";

export default function Navbar() {
  const { isAuthenticated, user } = useAuth();
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <nav className="command-panel fixed top-0 w-full z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-4">
            <div className="text-[var(--starcraft-amber)] font-orbitron text-xl font-bold crt-effect flex items-center">
              <Satellite className="mr-2" size={20} />
              DOJO STARCRAFT LEAGUE
            </div>
          </Link>
          
          {!isAuthenticated && (
            <div className="hidden md:flex items-center space-x-6">
              <Link href="/faq">
                <button className={`transition-colors ${isActive('/faq') ? 'text-[var(--starcraft-amber)]' : 'text-gray-300 hover:text-[var(--starcraft-amber)]'}`}>
                  PREGUNTAS FRECUENTES
                </button>
              </Link>
            </div>
          )}
          {isAuthenticated && (
            <div className="hidden md:flex items-center space-x-6">
              <Link href="/">
                <button className={`transition-colors ${isActive('/') ? 'text-[var(--starcraft-amber)]' : 'text-gray-300 hover:text-[var(--starcraft-amber)]'}`}>
                  INICIO
                </button>
              </Link>
              <Link href="/dashboard">
                <button className={`transition-colors ${isActive('/dashboard') ? 'text-[var(--starcraft-amber)]' : 'text-gray-300 hover:text-[var(--starcraft-amber)]'}`}>
                  PANEL DE CONTROL
                </button>
              </Link>
              <Link href="/upload">
                <button className={`transition-colors ${isActive('/upload') ? 'text-[var(--starcraft-amber)]' : 'text-gray-300 hover:text-[var(--starcraft-amber)]'}`}>
                  SUBIR REPLAY
                </button>
              </Link>
              <Link href="/faq">
                <button className={`transition-colors ${isActive('/faq') ? 'text-[var(--starcraft-amber)]' : 'text-gray-300 hover:text-[var(--starcraft-amber)]'}`}>
                  PREGUNTAS FRECUENTES
                </button>
              </Link>
              <div className="flex items-center space-x-4">
                {user && (
                  <div className="flex items-center space-x-2 text-[var(--starcraft-amber)] font-orbitron text-sm">
                    {user.profileImageUrl && (
                      <img 
                        src={user.profileImageUrl} 
                        alt="Profile" 
                        className="w-8 h-8 rounded border border-[var(--starcraft-amber)] object-cover"
                      />
                    )}
                    <span>OPERADOR: {user.firstName || user.email?.split('@')[0] || 'USUARIO'}</span>
                  </div>
                )}
                <a href="/api/logout" className="text-gray-300 hover:text-[var(--starcraft-amber)] transition-colors">
                  CERRAR SESIÓN
                </a>
              </div>
            </div>
          )}
          
          <StatusIndicator />
        </div>
      </div>
    </nav>
  );
}
