import { useState } from "react";
import { Panel } from "@/components/starcraft/panel";
import { DataTerminal } from "@/components/starcraft/data-terminal";
import { ChevronDown, ChevronUp, Shield, Mail } from "lucide-react";

interface FAQItem {
  id: number;
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    id: 1,
    question: "¿Cómo funciona el análisis de replays?",
    answer: "El sistema analiza automáticamente archivos .rep para extraer datos de partida incluyendo nombres de jugadores, razas, condiciones de victoria y duración del juego. Estos datos se usan para actualizar brackets de torneos en Challonge sin intervención manual."
  },
  {
    id: 2,
    question: "¿Qué formatos de archivo son compatibles?",
    answer: "Actualmente, solo se admiten archivos de replay de StarCraft: Brood War (.rep). Los archivos deben ser menores a 10MB y de partidas válidas de Brood War. Otros formatos serán rechazados por el sistema."
  },
  {
    id: 3,
    question: "¿Cómo conecto mi torneo de Challonge?",
    answer: "Necesitarás proporcionar tu clave API de Challonge y la URL del torneo durante la configuración. El sistema sincronizará automáticamente los resultados de partidas, actualizará brackets y rastreará el progreso del torneo en tiempo real."
  },
  {
    id: 4,
    question: "¿Qué pasa si un replay falla al procesarse?",
    answer: "Los replays fallidos se marcan en el panel de control con detalles del error. Problemas comunes incluyen archivos corruptos, versiones de juego no compatibles o partidas incompletas. Puedes volver a subir archivos corregidos en cualquier momento."
  },
  {
    id: 5,
    question: "¿Hay un límite de tiempo de procesamiento?",
    answer: "La mayoría de replays se procesan en 30 segundos. Partidas más largas o carga del servidor pueden aumentar el tiempo de procesamiento. El sistema mantiene una cola y procesa archivos en orden de subida."
  }
];

export default function FAQ() {
  const [openFAQs, setOpenFAQs] = useState<Set<number>>(new Set());

  const toggleFAQ = (id: number) => {
    const newOpenFAQs = new Set(openFAQs);
    if (newOpenFAQs.has(id)) {
      newOpenFAQs.delete(id);
    } else {
      newOpenFAQs.add(id);
    }
    setOpenFAQs(newOpenFAQs);
  };

  return (
    <div className="pt-20 container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* FAQ Header */}
        <Panel className="mb-8">
          <h1 className="font-orbitron text-2xl font-bold text-[var(--starcraft-amber)]">BASE DE DATOS TÁCTICA</h1>
          <p className="text-gray-400">Información de Acceso Frecuente</p>
        </Panel>

        {/* FAQ Items */}
        <div className="space-y-6">
          {faqData.map((faq) => (
            <DataTerminal key={faq.id}>
              <button 
                className="w-full text-left"
                onClick={() => toggleFAQ(faq.id)}
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)]">
                    {faq.question}
                  </h3>
                  {openFAQs.has(faq.id) ? (
                    <ChevronUp className="text-[var(--starcraft-amber)]" size={20} />
                  ) : (
                    <ChevronDown className="text-[var(--starcraft-amber)]" size={20} />
                  )}
                </div>
              </button>
              {openFAQs.has(faq.id) && (
                <div className="mt-4 text-gray-400">
                  <p>{faq.answer}</p>
                </div>
              )}
            </DataTerminal>
          ))}
        </div>

        {/* Contact Terminal */}
        <Panel className="mt-12">
          <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4 flex items-center">
            <Shield className="mr-2" size={20} />
            CANAL DE SOPORTE
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-[var(--starcraft-amber)] font-bold mb-2 flex items-center">
                <Mail className="mr-2" size={16} />
                Soporte Técnico
              </h4>
              <p className="text-gray-400 text-sm">Para errores del sistema y problemas técnicos</p>
              <p className="text-[var(--starcraft-amber)] text-sm">soporte@dojo-starcraft.com</p>
            </div>
            <div>
              <h4 className="text-[var(--starcraft-amber)] font-bold mb-2 flex items-center">
                <Mail className="mr-2" size={16} />
                Operaciones de Torneos
              </h4>
              <p className="text-gray-400 text-sm">Para configuración y gestión de torneos</p>
              <p className="text-[var(--starcraft-amber)] text-sm">torneos@dojo-starcraft.com</p>
            </div>
          </div>
        </Panel>

        {/* Footer Info */}
        <div className="mt-8 text-center">
          <div className="font-orbitron text-[var(--starcraft-amber)] mb-2">
            DOJO STARCRAFT LEAGUE
          </div>
          <div className="text-xs text-gray-500 flex items-center justify-center">
            <Shield className="mr-1" size={12} />
            OPERACIONES TÁCTICAS SEGURAS | TECNOLOGÍA TERRAN
          </div>
          <div className="text-xs text-gray-500 mt-2">
            © 2025 Dojo Starcraft League. Todos los datos tácticos asegurados.
          </div>
        </div>
      </div>
    </div>
  );
}
