import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Panel } from "@/components/starcraft/panel";
import { DataTerminal } from "@/components/starcraft/data-terminal";
import { CommandPanel } from "@/components/starcraft/command-panel";
import { Link } from "wouter";
import { Upload, Trophy, BarChart3, Activity, AlertCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: stats = { totalReplays: 0, tournaments: 0, pendingReplays: 0 }, isLoading: statsLoading, error: statsError } = useQuery<any>({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
  });

  const { data: tournaments = [], isLoading: tournamentsLoading, error: tournamentsError } = useQuery<any[]>({
    queryKey: ["/api/tournaments"],
    retry: false,
  });

  const { data: replays = [], isLoading: replaysLoading, error: replaysError } = useQuery<any[]>({
    queryKey: ["/api/replays"],
    retry: false,
  });

  useEffect(() => {
    if (statsError && isUnauthorizedError(statsError)) {
      toast({
        title: "No Autorizado",
        description: "Sesión expirada. Redirigiendo al acceso...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [statsError, toast]);

  if (statsLoading || tournamentsLoading || replaysLoading) {
    return (
      <div className="pt-20 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Panel>
            <div className="text-center">
              <div className="loading-bar w-32 h-2 mb-4 mx-auto"></div>
              <p className="font-orbitron text-[var(--starcraft-amber)]">INICIALIZANDO CENTRO DE COMANDO...</p>
            </div>
          </Panel>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Dashboard Header */}
        <Panel className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-orbitron text-2xl font-bold text-[var(--starcraft-amber)]">CENTRO DE COMANDO</h1>
              <p className="text-gray-400">Panel de Control de Misión</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="status-indicator text-[var(--starcraft-green)] flex items-center">
                <div className="w-2 h-2 rounded-full bg-[var(--starcraft-green)] mr-2"></div>
                <span className="text-sm font-orbitron">TODOS LOS SISTEMAS NOMINALES</span>
              </div>
            </div>
          </div>
        </Panel>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Link href="/upload">
            <CommandPanel className="text-left">
              <Upload className="text-[var(--starcraft-amber)] text-2xl mb-3" size={32} />
              <h3 className="font-orbitron text-lg font-bold mb-2">SUBIR REPLAY</h3>
              <p className="text-gray-400 text-sm">Desplegar nuevos datos de misión</p>
            </CommandPanel>
          </Link>
          
          <CommandPanel>
            <Trophy className="text-[var(--starcraft-amber)] text-2xl mb-3" size={32} />
            <h3 className="font-orbitron text-lg font-bold mb-2">TORNEOS ACTIVOS</h3>
            <p className="text-gray-400 text-sm">{tournaments?.length || 0} operaciones en curso</p>
          </CommandPanel>
          
          <CommandPanel>
            <BarChart3 className="text-[var(--starcraft-amber)] text-2xl mb-3" size={32} />
            <h3 className="font-orbitron text-lg font-bold mb-2">ESTADO DE PARTIDAS</h3>
            <p className="text-gray-400 text-sm">{stats?.pendingReplays || 0} análisis pendientes</p>
          </CommandPanel>
        </div>

        {/* Tournament Selection */}
        <Panel className="mb-8">
          <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4">SELECCIÓN DE TORNEO</h3>
          <DataTerminal className="p-4">
            <Select>
              <SelectTrigger className="w-full bg-[var(--starcraft-dark)] border-[var(--starcraft-gunmetal)] text-[var(--starcraft-amber)] font-orbitron">
                <SelectValue placeholder="SELECCIONAR TORNEO ACTIVO..." />
              </SelectTrigger>
              <SelectContent>
                {tournaments?.length > 0 ? (
                  tournaments.map((tournament: any) => (
                    <SelectItem key={tournament.id} value={tournament.id.toString()}>
                      {tournament.name}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value="none" disabled>No hay torneos disponibles</SelectItem>
                )}
              </SelectContent>
            </Select>
          </DataTerminal>
        </Panel>

        {/* Recent Activity */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Match Results */}
          <DataTerminal>
            <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4 flex items-center">
              <Activity className="mr-2" size={20} />
              RECENT MATCH RESULTS
            </h3>
            <div className="space-y-3">
              {replays?.length > 0 ? (
                replays.slice(0, 5).map((replay: any) => (
                  <div key={replay.id} className="flex justify-between items-center py-2 border-b border-[var(--starcraft-gunmetal)]">
                    <span className="text-sm">{replay.filename}</span>
                    <span className={`text-sm ${
                      replay.status === 'completed' ? 'text-[var(--starcraft-green)]' : 
                      replay.status === 'processing' ? 'text-[var(--starcraft-amber)]' : 
                      replay.status === 'failed' ? 'text-[var(--starcraft-red)]' :
                      'text-gray-500'
                    }`}>
                      {replay.status.toUpperCase()}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center text-gray-500 py-8">
                  <AlertCircle className="mx-auto mb-2" size={32} />
                  <p>No replays processed yet</p>
                  <p className="text-xs mt-2">Upload your first replay to begin</p>
                </div>
              )}
            </div>
          </DataTerminal>

          {/* System Status */}
          <DataTerminal>
            <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4">SYSTEM STATUS</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Replay Processing</span>
                  <span className="text-[var(--starcraft-green)]">87%</span>
                </div>
                <div className="w-full bg-[var(--starcraft-darker)] h-2">
                  <div className="loading-bar h-2 w-[87%]"></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>API Sync Status</span>
                  <span className="text-[var(--starcraft-green)]">100%</span>
                </div>
                <div className="w-full bg-[var(--starcraft-darker)] h-2">
                  <div className="bg-[var(--starcraft-green)] h-2 w-full"></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Server Load</span>
                  <span className="text-[var(--starcraft-amber)]">34%</span>
                </div>
                <div className="w-full bg-[var(--starcraft-darker)] h-2">
                  <div className="bg-[var(--starcraft-amber)] h-2 w-[34%]"></div>
                </div>
              </div>
            </div>
          </DataTerminal>
        </div>
      </div>
    </div>
  );
}
