import { Panel } from "@/components/starcraft/panel";
import { DataTerminal } from "@/components/starcraft/data-terminal";
import { Microscope, RotateCcw, Trophy, Shield, Target, Zap } from "lucide-react";

export default function Landing() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <div className="relative min-h-screen bg-terminal-lines">
        <div className="absolute inset-0 opacity-20 bg-grid-pattern"></div>
        
        <div className="relative z-10 container mx-auto px-4 py-20">
          <div className="max-w-6xl mx-auto">
            {/* Main Hero Panel */}
            <Panel className="mb-12 scan-line">
              <div className="text-center">
                <h1 className="font-orbitron text-4xl md:text-6xl font-black text-[var(--starcraft-amber)] mb-4 crt-effect">
                  DOJO STARCRAFT LEAGUE
                </h1>
                <h2 className="font-orbitron text-xl md:text-2xl text-gray-300 mb-6">
                  SISTEMA DE GESTIÓN DE TORNEOS
                </h2>
                <p className="text-lg text-gray-400 max-w-3xl mx-auto mb-8">
                  Plataforma profesional de gestión de torneos para StarCraft: Brood War competitivo. 
                  Sube archivos de replay (.rep) para procesamiento automático y sincroniza resultados directamente con brackets de Challonge.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a href="/api/login" className="glow-button bg-[var(--starcraft-amber)] text-[var(--starcraft-dark)] px-8 py-3 font-orbitron font-bold inline-block text-center">
                    INICIALIZAR COMANDO
                  </a>
                </div>
              </div>
            </Panel>

            {/* Feature Grid */}
            <div className="grid md:grid-cols-3 gap-6">
              {/* Replay Analysis */}
              <DataTerminal>
                <div className="flex items-center mb-4">
                  <Microscope className="text-[var(--starcraft-amber)] text-2xl mr-3" size={32} />
                  <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)]">ANÁLISIS DE REPLAYS</h3>
                </div>
                <p className="text-gray-400 mb-4">
                  Análisis avanzado de archivos .rep extrae datos de partida, acciones de jugadores y condiciones de victoria automáticamente.
                </p>
                <div className="text-xs text-[var(--starcraft-green)] flex items-center">
                  <Shield className="mr-1" size={12} />
                  AUTO-DETECCIÓN ACTIVADA
                </div>
              </DataTerminal>

              {/* Tournament Sync */}
              <DataTerminal>
                <div className="flex items-center mb-4">
                  <RotateCcw className="text-[var(--starcraft-amber)] text-2xl mr-3" size={32} />
                  <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)]">SINCRONIZACIÓN CHALLONGE</h3>
                </div>
                <p className="text-gray-400 mb-4">
                  Actualizaciones en tiempo real de brackets mediante integración con API de Challonge. No requiere entrada manual de resultados.
                </p>
                <div className="text-xs text-[var(--starcraft-green)] flex items-center">
                  <Target className="mr-1" size={12} />
                  ENLACE ESTABLECIDO
                </div>
              </DataTerminal>

              {/* Tournament Management */}
              <DataTerminal>
                <div className="flex items-center mb-4">
                  <Trophy className="text-[var(--starcraft-amber)] text-2xl mr-3" size={32} />
                  <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)]">CONTROL DE TORNEOS</h3>
                </div>
                <p className="text-gray-400 mb-4">
                  Supervisión completa de torneos con seguimiento de partidas, estadísticas de jugadores y monitoreo de progreso.
                </p>
                <div className="text-xs text-[var(--starcraft-green)] flex items-center">
                  <Zap className="mr-1" size={12} />
                  SISTEMAS OPERACIONALES
                </div>
              </DataTerminal>
            </div>

            {/* Stats Dashboard Preview */}
            <Panel className="mt-12">
              <h3 className="font-orbitron text-xl font-bold text-[var(--starcraft-amber)] mb-6 text-center">
                RESUMEN TÁCTICO
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-orbitron font-bold text-[var(--starcraft-green)]">1,247</div>
                  <div className="text-xs text-gray-400">REPLAYS PROCESADOS</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-orbitron font-bold text-[var(--starcraft-amber)]">89</div>
                  <div className="text-xs text-gray-400">TORNEOS ACTIVOS</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-orbitron font-bold text-blue-400">456</div>
                  <div className="text-xs text-gray-400">JUGADORES REGISTRADOS</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-orbitron font-bold text-purple-400">99.7%</div>
                  <div className="text-xs text-gray-400">TIEMPO DE ACTIVIDAD</div>
                </div>
              </div>
            </Panel>
          </div>
        </div>
      </div>
    </div>
  );
}
