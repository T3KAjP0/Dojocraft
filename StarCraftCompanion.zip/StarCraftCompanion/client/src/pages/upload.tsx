import { useState, useCallback, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Panel } from "@/components/starcraft/panel";
import { DataTerminal } from "@/components/starcraft/data-terminal";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CloudUpload, File, CheckCircle, AlertCircle, Info } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Upload() {
  const [selectedTournament, setSelectedTournament] = useState<string>("");
  const [dragActive, setDragActive] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "No Autorizado",
        description: "Sesión expirada. Redirigiendo al acceso...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: tournaments = [], isLoading: tournamentsLoading } = useQuery<any[]>({
    queryKey: ["/api/tournaments"],
  });

  const { data: replays = [], isLoading: replaysLoading } = useQuery<any[]>({
    queryKey: ["/api/replays"],
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('replay', file);
      if (selectedTournament) {
        formData.append('tournamentId', selectedTournament);
      }
      
      const response = await fetch('/api/replays/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Subida Exitosa",
        description: "Archivo de replay desplegado para análisis",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/replays"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "No Autorizado",
          description: "Sesión expirada. Redirigiendo al acceso...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error de Subida",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.rep')) {
        uploadMutation.mutate(file);
      } else {
        toast({
          title: "Tipo de Archivo Inválido",
          description: "Solo se admiten archivos .rep",
          variant: "destructive",
        });
      }
    }
  }, [uploadMutation, toast]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.name.endsWith('.rep')) {
        uploadMutation.mutate(file);
      } else {
        toast({
          title: "Tipo de Archivo Inválido",
          description: "Solo se admiten archivos .rep",
          variant: "destructive",
        });
      }
    }
  }, [uploadMutation, toast]);

  if (tournamentsLoading || replaysLoading) {
    return (
      <div className="pt-20 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Panel>
            <div className="text-center">
              <div className="loading-bar w-32 h-2 mb-4 mx-auto"></div>
              <p className="font-orbitron text-[var(--starcraft-amber)]">INICIALIZANDO TERMINAL DE SUBIDA...</p>
            </div>
          </Panel>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Upload Header */}
        <Panel className="mb-8">
          <h1 className="font-orbitron text-2xl font-bold text-[var(--starcraft-amber)]">TERMINAL DE SUBIDA DE REPLAYS</h1>
          <p className="text-gray-400">Desplegar datos de misión para análisis táctico</p>
        </Panel>

        {/* Tournament Selection */}
        <DataTerminal className="mb-8">
          <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4">SELECCIONAR TORNEO OBJETIVO</h3>
          <Select value={selectedTournament} onValueChange={setSelectedTournament}>
            <SelectTrigger className="w-full bg-[var(--starcraft-dark)] border-[var(--starcraft-gunmetal)] text-[var(--starcraft-amber)] font-orbitron mb-4">
              <SelectValue placeholder="ESPERANDO SELECCIÓN DE TORNEO..." />
            </SelectTrigger>
            <SelectContent>
              {tournaments?.length > 0 ? (
                tournaments.map((tournament: any) => (
                  <SelectItem key={tournament.id} value={tournament.id.toString()}>
                    {tournament.name}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="none" disabled>No hay torneos disponibles</SelectItem>
              )}
            </SelectContent>
          </Select>
          <div className="text-xs text-gray-500 flex items-center">
            <Info className="mr-1" size={12} />
            Asegurar que el torneo esté activo en Challonge antes de subir replays
          </div>
        </DataTerminal>

        {/* File Upload Area */}
        <Panel className="mb-8">
          <div
            className={`border-2 border-dashed p-12 text-center data-terminal transition-colors ${
              dragActive 
                ? "border-[var(--starcraft-amber)] bg-[var(--starcraft-amber)]/10" 
                : "border-[var(--starcraft-amber)]"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <CloudUpload className="text-6xl text-[var(--starcraft-amber)] mb-4 mx-auto" size={64} />
            <h3 className="font-orbitron text-xl font-bold text-[var(--starcraft-amber)] mb-2">DESPLEGAR ARCHIVOS DE REPLAY</h3>
            <p className="text-gray-400 mb-4">Arrastra y suelta archivos .rep o haz clic para seleccionar</p>
            <div className="relative">
              <input
                type="file"
                accept=".rep"
                onChange={handleFileInput}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={uploadMutation.isPending}
              />
              <Button 
                className="glow-button bg-[var(--starcraft-amber)] text-[var(--starcraft-dark)] px-6 py-3 font-orbitron font-bold"
                disabled={uploadMutation.isPending}
              >
                {uploadMutation.isPending ? "PROCESANDO..." : "SELECCIONAR ARCHIVOS"}
              </Button>
            </div>
            <div className="mt-4 text-xs text-gray-500 flex items-center justify-center">
              <AlertCircle className="mr-1" size={12} />
              Tamaño máximo de archivo: 10MB | Soportado: solo archivos .rep
            </div>
          </div>
        </Panel>

        {/* Upload Queue */}
        <DataTerminal>
          <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4">COLA DE SUBIDA</h3>
          <div className="space-y-3">
            {replays?.length > 0 ? (
              replays.slice(0, 10).map((replay: any) => (
                <div key={replay.id} className="flex items-center justify-between py-3 border-b border-[var(--starcraft-gunmetal)]">
                  <div className="flex items-center">
                    <File className="text-[var(--starcraft-amber)] mr-3" size={20} />
                    <div>
                      <div className="text-sm font-medium">{replay.filename}</div>
                      <div className="text-xs text-gray-500">
                        {new Date(replay.createdAt).toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    {replay.status === 'completed' && (
                      <>
                        <span className="text-[var(--starcraft-green)] text-sm mr-2">COMPLETO</span>
                        <CheckCircle className="text-[var(--starcraft-green)]" size={16} />
                      </>
                    )}
                    {replay.status === 'processing' && (
                      <>
                        <span className="text-[var(--starcraft-amber)] text-sm mr-2">PROCESANDO</span>
                        <div className="loading-bar w-8 h-2"></div>
                      </>
                    )}
                    {replay.status === 'failed' && (
                      <>
                        <span className="text-[var(--starcraft-red)] text-sm mr-2">FALLIDO</span>
                        <AlertCircle className="text-[var(--starcraft-red)]" size={16} />
                      </>
                    )}
                    {replay.status === 'queued' && (
                      <span className="text-gray-500 text-sm">EN COLA</span>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center text-gray-500 py-8">
                <CloudUpload className="mx-auto mb-2" size={32} />
                <p>No hay archivos en cola</p>
                <p className="text-xs mt-2">Sube tu primer archivo de replay para comenzar el análisis</p>
              </div>
            )}
          </div>
        </DataTerminal>
      </div>
    </div>
  );
}
