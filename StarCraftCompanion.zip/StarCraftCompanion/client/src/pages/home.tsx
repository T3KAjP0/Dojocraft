import { useQuery } from "@tanstack/react-query";
import { Panel } from "@/components/starcraft/panel";
import { DataTerminal } from "@/components/starcraft/data-terminal";
import { CommandPanel } from "@/components/starcraft/command-panel";
import { Link } from "wouter";
import { Upload, Trophy, BarChart3, Activity } from "lucide-react";

export default function Home() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="pt-20 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Panel>
            <div className="text-center">
              <div className="loading-bar w-32 h-2 mb-4 mx-auto"></div>
              <p className="font-orbitron text-[var(--starcraft-amber)]">LOADING TACTICAL DATA...</p>
            </div>
          </Panel>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Welcome Header */}
        <Panel className="mb-8">
          <div className="text-center">
            <h1 className="font-orbitron text-3xl font-bold text-[var(--starcraft-amber)] mb-4 crt-effect">
              COMMAND CENTER ONLINE
            </h1>
            <p className="text-gray-400">Welcome back, Commander. All systems operational.</p>
          </div>
        </Panel>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Link href="/upload">
            <CommandPanel className="text-left">
              <Upload className="text-[var(--starcraft-amber)] text-2xl mb-3" size={32} />
              <h3 className="font-orbitron text-lg font-bold mb-2">DEPLOY REPLAY</h3>
              <p className="text-gray-400 text-sm">Upload new mission data</p>
            </CommandPanel>
          </Link>
          
          <Link href="/dashboard">
            <CommandPanel className="text-left">
              <BarChart3 className="text-[var(--starcraft-amber)] text-2xl mb-3" size={32} />
              <h3 className="font-orbitron text-lg font-bold mb-2">TACTICAL OVERVIEW</h3>
              <p className="text-gray-400 text-sm">Mission status dashboard</p>
            </CommandPanel>
          </Link>
          
          <CommandPanel>
            <Trophy className="text-[var(--starcraft-amber)] text-2xl mb-3" size={32} />
            <h3 className="font-orbitron text-lg font-bold mb-2">ACTIVE TOURNAMENTS</h3>
            <p className="text-gray-400 text-sm">{stats?.tournaments || 0} ongoing operations</p>
          </CommandPanel>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-2 gap-6">
          <DataTerminal>
            <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4 flex items-center">
              <Activity className="mr-2" size={20} />
              MISSION STATISTICS
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span>Total Replays Processed</span>
                <span className="text-[var(--starcraft-green)] font-orbitron">{stats?.totalReplays || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>Active Tournaments</span>
                <span className="text-[var(--starcraft-amber)] font-orbitron">{stats?.tournaments || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>Pending Analysis</span>
                <span className="text-orange-400 font-orbitron">{stats?.pendingReplays || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>System Status</span>
                <span className="text-[var(--starcraft-green)] font-orbitron">OPERATIONAL</span>
              </div>
            </div>
          </DataTerminal>

          <DataTerminal>
            <h3 className="font-orbitron text-lg font-bold text-[var(--starcraft-amber)] mb-4">RECENT ACTIVITY</h3>
            <div className="space-y-3">
              {stats?.recentReplays?.length > 0 ? (
                stats.recentReplays.map((replay: any, index: number) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b border-[var(--starcraft-gunmetal)]">
                    <span className="text-sm">{replay.filename}</span>
                    <span className={`text-sm ${
                      replay.status === 'completed' ? 'text-[var(--starcraft-green)]' : 
                      replay.status === 'processing' ? 'text-[var(--starcraft-amber)]' : 
                      'text-gray-500'
                    }`}>
                      {replay.status.toUpperCase()}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center text-gray-500 py-8">
                  <p>No recent activity</p>
                  <p className="text-xs mt-2">Upload your first replay to get started</p>
                </div>
              )}
            </div>
          </DataTerminal>
        </div>
      </div>
    </div>
  );
}
