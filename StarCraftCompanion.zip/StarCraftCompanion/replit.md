# Dojo Starcraft League - Tournament Management System

## Overview

This is a full-stack web application designed for professional StarCraft: Brood War tournament management and replay analysis. The Dojo Starcraft League platform allows users to upload .rep files (StarCraft replay files), automatically processes them to extract match data, and provides integration with Challonge tournament brackets for automated result synchronization.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for development and build tooling
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Custom StarCraft-themed components built on Radix UI primitives with shadcn/ui
- **Styling**: Tailwind CSS with custom StarCraft-inspired color schemes and animations
- **Theme**: Dark sci-fi aesthetic matching StarCraft: Brood War's visual design

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **File Upload**: Multer middleware for handling .rep file uploads (10MB limit)
- **Session Management**: Express-session with PostgreSQL session store

### Database Architecture
- **Primary Database**: PostgreSQL using Neon serverless
- **ORM**: Drizzle ORM with schema-first approach
- **Key Tables**:
  - `users`: User profiles and authentication data
  - `sessions`: Session storage (required for Replit Auth)
  - `tournaments`: Tournament metadata and Challonge integration
  - `replays`: Replay file metadata and processing status

## Key Components

### Authentication System
- **Provider**: Replit Auth with OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions with 7-day TTL
- **Middleware**: Custom authentication middleware for protected routes
- **User Management**: Automatic user creation and profile management

### File Processing System
- **Upload Handling**: Multer-based file upload with .rep file validation
- **Storage**: Local file system storage in `/uploads` directory
- **Processing**: Automatic replay parsing to extract match metadata
- **Error Handling**: Comprehensive error reporting for failed uploads

### Tournament Integration
- **Challonge API**: Integration for bracket management and result synchronization
- **Tournament Types**: Support for various tournament formats
- **Status Tracking**: Real-time tournament status monitoring

### UI Component System
- **StarCraft Theme**: Custom components (Panel, DataTerminal, CommandPanel)
- **Responsive Design**: Mobile-first approach with desktop enhancements
- **Visual Effects**: CRT monitor effects, scan lines, and retro-futuristic styling
- **Loading States**: Themed loading animations and skeleton screens

## Data Flow

1. **User Authentication**: Users authenticate via Replit Auth, creating session records
2. **Tournament Setup**: Users create tournaments with optional Challonge integration
3. **Replay Upload**: Users upload .rep files through drag-and-drop interface
4. **File Processing**: Server validates, stores, and parses replay files
5. **Data Extraction**: Match results extracted from replay files
6. **Bracket Updates**: Results automatically sync to Challonge brackets
7. **Dashboard Display**: Processed data displayed in themed dashboard interface

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL serverless database
- **Authentication**: Replit Auth system with OpenID Connect
- **File Storage**: Local filesystem with configurable upload limits
- **Session Management**: PostgreSQL session store

### Third-party Services
- **Challonge API**: Tournament bracket management
- **Replit Infrastructure**: Hosting and deployment platform

### Development Tools
- **Vite**: Development server and build tool
- **TypeScript**: Type safety and development experience
- **Drizzle Kit**: Database schema management and migrations

## Deployment Strategy

### Development Environment
- **Platform**: Replit with integrated development environment
- **Hot Reload**: Vite development server with HMR
- **Database**: Shared Neon PostgreSQL instance
- **File Storage**: Local uploads directory

### Production Deployment
- **Platform**: Replit autoscale deployment
- **Build Process**: Vite production build with asset optimization
- **Server**: Node.js with Express serving both API and static files
- **Database**: Production Neon PostgreSQL with connection pooling
- **Port Configuration**: Port 5000 mapped to external port 80

### Environment Configuration
- **Environment Variables**: DATABASE_URL, SESSION_SECRET, REPL_ID
- **Module System**: ES modules throughout the application
- **TypeScript**: Compilation-free runtime with TSX

## User Preferences

Preferred communication style: Simple, everyday language.
Language preference: Spanish interface
Branding: "Dojo Starcraft League" instead of generic StarCraft naming

## Changelog

Changelog:
- June 19, 2025. Initial setup with StarCraft-themed tournament management system
- June 19, 2025. Updated branding to "Dojo Starcraft League" 
- June 19, 2025. Complete Spanish localization of user interface
- June 19, 2025. Re-enabled authentication system with full functionality
- June 19, 2025. Fixed database schema for replay uploads and tournament integration